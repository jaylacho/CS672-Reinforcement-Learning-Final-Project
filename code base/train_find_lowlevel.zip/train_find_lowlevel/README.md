### Training Low-level policy for Find-skills

refer to train_xxx_navigation.py.