from .compass_mlp import CompassMLP
