from .dummy_img_feat import DummyImgFeat
