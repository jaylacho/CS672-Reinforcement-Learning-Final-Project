from .biome_id_emb import BiomeIDEmb
