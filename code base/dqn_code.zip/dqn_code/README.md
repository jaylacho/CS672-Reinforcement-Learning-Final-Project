### DQN

- Place the two files in the previous ppo training path.

- Check the env and hyperparams used in this code.

- Train DQN: run `MINEDOJO_HEADLESS=1 python train_dqn.py`.
